/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "AD9910V2.h"
#include "si5351.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint8_t PLL_LOCK_FLAG;
uint16_t plusedelay = 90;//，延时时间，代表0.09ms
uint16_t plusewidth = 10;//脉冲宽度，代�?????????10us
uint8_t cmd = 0;

/*串口控制DDS
协议规定�?????????
接收�?????????
头帧 | 波形 | 参数 | 尾帧
参数(正弦 B1)：幅�?????????+频率
参数(啁啾 B2)：起始频�????????? - 终止频率 - 扫频时间 - 步进时间 - 扫频方向 - 触发模式
接收：A5 | 波形 | (参数) | 5A
发�?�：5A
*/
#define DATA_MAX 20 //�?????????大数组接收量
uint8_t RxBuf[DATA_MAX];
uint8_t RxPoint = 0;//用于计算接收个数
uint8_t RxData;//用于接收单个数字
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_SPI1_Init();
  MX_TIM1_Init();
  MX_USART3_UART_Init();
  /* USER CODE BEGIN 2 */
  //�?????????启串口接收中�?????????
  //HAL_UART_Receive_IT(&huart3, &RxData, 1);

  AD9910_Init();
  AD9910_Freq_Convert(2000000);
  // 起始频率 - 终止频率 - 扫频时间 - 步进时间 - 扫频方向 - 触发模式 后两个只在外触发模式下有�?
  //FRE_HIGH_LOW:ch3 high;ch1 low
  //时间得为两�?�的时间�?2000实际上是1us 用于正负扫频选取
  AD9910_RAMP_Chrip_generate(168000000, 218000000, 2000, 4, FRE_HIGH_LOW,INSIDE_TRIG);
  //AD9910_AMP_Convert(650) ;
  //AD9910_RAM_Chrip_generate(168000000, 218000000, 1000, 4, FRE_HIGH_LOW);
  AD9910_AMP_Convert(650);
  //AD9910_ReInit_PFx();//重新将STM32端的三个引脚浮空

  HAL_GPIO_DeInit(IO_UPDATE_GPIO_Port, IO_UPDATE_Pin);
  //HAL_Delay(500);

  //__HAL_TIM_SET_AUTORELOAD(&htim1,plusedelay + plusewidth - 2);//设置脉冲宽度
  //__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_1,plusewidth - 1); //设置OSK脉冲延时
  //__HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_3,plusewidth - 1); //设置CRTL或profile0脉冲延时


  //HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);
  //HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_3);
  //HAL_TIM_OnePulse_Start(&htim1, TIM_CHANNEL_1);
  //HAL_TIM_OnePulse_Start(&htim1, TIM_CHANNEL_3);
  //HAL_TIM_Base_Start_IT(&htim1);

  printf("Initial is ready!\r\n");
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	 //读取PLL_LOCK时钟引脚，准备显示在OLED上，表示
	 PLL_LOCK_FLAG = HAL_GPIO_ReadPin(PLL_LOCK_GPIO_Port,PLL_LOCK_Pin);
	 //printf("PLL_LOCK_FLAG is %d\r\n",PLL_LOCK_FLAG);
	 PLL_LOCK_FLAG = HAL_GPIO_ReadPin(SWEEP_SEL_GPIO_Port,SWEEP_SEL_Pin);
	 //printf("SWEEP_SEL is %d\r\n",PLL_LOCK_FLAG);
	 HAL_Delay(1000);


	 //HAL_UART_Receive_IT(&huart3, &cmd, 1);

  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_I2C1|RCC_PERIPHCLK_TIM1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_SYSCLK;
  PeriphClkInit.Tim1ClockSelection = RCC_TIM1CLK_HCLK;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PWM_PulseFinishedCallback(TIM_HandleTypeDef *htim)
{

}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if(htim == (&htim1))
    {
    	//AD9910_Phase_Clean();
    	printf("Phase is Clean!\r\n");
    }
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(GPIO_Pin == TRIG_Pin)
	{
		//AD9910_Phase_Clean();
		//printf("Phase is Clean!\r\n");
		//每当外部中断被触发一次，打开PWM产生1个单脉冲
		__HAL_TIM_ENABLE(&htim1);
		//AD9910_Phase_Clean();
		printf("Phase is Clean!\r\n");
		printf("PWM is been generated.\r\n");
		__HAL_GPIO_EXTI_CLEAR_IT(TRIG_Pin);
		//AD9910_Phase_Clean();
		//printf("Phase is Clean!\r\n");
	}
}
//串口接收
/*
uint8_t RX_Flag = 0;;
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance == USART3){
		if(RxPoint == DATA_MAX)//防止溢出
		{
			RxPoint = 0;
		}
		//将接收到的单个字符扔到自定义字符串缓冲中，形成字符串
		RxBuf[RxPoint++] = RxData;
		RX_Flag = 1;
		HAL_UART_Receive_IT(&huart3, &RxData, 1);
	}
}*/

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
